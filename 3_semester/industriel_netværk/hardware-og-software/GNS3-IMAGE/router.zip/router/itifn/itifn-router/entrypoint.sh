#!/bin/sh
set -eu
IFACES="${IFACES:-all default lo eth0}"
for iface in $IFACES; do
  sysctl -w "net.ipv6.conf.${iface}.autoconf=0" >/dev/null || true
  sysctl -w "net.ipv6.conf.${iface}.dad_transmits=0" >/dev/null || true
  sysctl -w "net.ipv6.conf.${iface}.accept_ra=0" >/dev/null || true
  sysctl -w "net.ipv6.conf.${iface}.router_solicitations=0" >/dev/null || true
done
[ "${IPV4_FORWARD:-0}" = "1" ] && sysctl -w net.ipv4.ip_forward=1 >/dev/null || true
[ "${IPV6_FORWARD:-0}" = "1" ] && sysctl -w net.ipv6.conf.all.forwarding=1 >/dev/null || true
exec "$@"
